
import javafx.concurrent.Task;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class FaceTaskWinking extends Task<Void>
{
    private Arc mouth;
    private Arc eye;
    private Stage stage;
    
    public FaceTaskWinking(Arc mouthIn, Arc eyeIn, Stage stageIn)
    {
        mouth = mouthIn;
        stage = stageIn;
        eye = eyeIn;
    }
    
    @Override
    protected Void call()
    {
        boolean go = true;
        while(go)
        {
               mouth.setLength(-180); // smiling mouth
         
               try
               {
                     Thread.sleep(500); //force the thread to sleep for 1 second
               }
               catch(InterruptedException e)
               {
               } 

               mouth.setLength(180);  // frowning mouth
               eye.setRadiusY(10);               try
               {
                        Thread.sleep(500); //force the thread to sleep for 1 second
               }
               catch(InterruptedException e)
               {
               } 
                   
                   
                            
               eye.setRadiusY(0);
               try
               {
                     Thread.sleep(1000); //force the thread to sleep for 1 second
               }
               catch(InterruptedException e)
               {
               } 

               eye.setRadiusY(10);
               try
               {
                        Thread.sleep(1000); //force the thread to sleep for 1 second
               }
               catch(InterruptedException e)
               {
               }    
                      
                   
               if(!stage.isShowing())
               {
                       go = false;
               }  
           }
           return null;
        }
}
 
