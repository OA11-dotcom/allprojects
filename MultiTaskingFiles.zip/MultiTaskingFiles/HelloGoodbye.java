import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.text.Text;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class HelloGoodbye extends Application
{
    private Text text = new Text(60, 240, "Hello");
                  
    public void start (Stage stage)
    {         
        text.setFont(Font.font ("Verdana", 25));
        text.setFill(Color.BLUE);
        VBox root = new VBox();
        root.setBackground(Background.EMPTY);
        root.setAlignment(Pos.CENTER);
        root.getChildren().add(text);
        Scene scene = new Scene(root, 200, 200);
        stage.setScene(scene);
        stage.setTitle("Hello-Goodbye");
        stage.show(); 
        begin(stage);
    }
        
    private void begin(Stage stageIn)  
    { 
        Thread thread1 = new Thread(new Task<Void>() 
        { 
            
             @Override
             protected Void call() 
             {
                /* Code goes here. The code will need to be in a while loop that terminates when the 
                 window closes. The Stage class has a method called isShowing that can be used to
                 terminate the loop. The thread will need to sleep for 1000 ms after each change.
                 Look at the FaceTask in chapter 20 to help you. */

            }
        });
        thread1.start();
    }

    public static void main(String[] args)
    {
        launch(args);
    }
}
