package com.cn6035.lab.hotelApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelSpringApp {

	public static void main(String[] args) {
		SpringApplication.run(HotelSpringApp.class, args);
	}

}
