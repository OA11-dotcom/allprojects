 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EmergencyServices;

public class Emergency
{
    private String address;
    private String serviceRequired;
    private Boolean completed;
    
    public Emergency(String addressIn, String serviceRequiredIn)
    {
            address = addressIn;
            serviceRequired = serviceRequiredIn; 
            completed = false;
    }
    
    public String getAddress()
    {
        return address;
    }
    
    public String getServiceRequired()
    {
        return serviceRequired;
    }
    
    
    public boolean getCompleted()
    {
        return completed;
    }
    
    public void markAsCompleted()
    {
        completed = true;
    }
    
}