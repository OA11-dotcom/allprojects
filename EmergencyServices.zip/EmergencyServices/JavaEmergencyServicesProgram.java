
package EmergencyServices;

import java.util.ArrayList;
import java.util.List;


public class JavaEmergencyServicesProgram {
    public static void main(String[] args)
    {
    char choice;
    int total;
    
    List<Emergency> listEmergency = new ArrayList<>();
    
    do
    {
        System.out.println();
        System.out.println("1. Add Emergency");
        System.out.println("2. Display All Emergencies");
        System.out.println("3. Mark Emergency as completed");
        System.out.println("4. List uncompleted emergencies");
        System.out.println("5. Quit");
        System.out.println();
        System.out.println("Enter choice [1-5]");
        
        choice = EasyScanner.nextChar();
        System.out.println();
        
        switch(choice)
        {
            case '1': option1(listEmergency);
            break;

            case '2': option2(listEmergency);
            break;

            case '3': option3(listEmergency);
            break;
            
            case '4': option4(listEmergency);
            break;

            case '5': break;
            default: System.out.println("Invalid Entry");

        }
        
      
    
    }
    while (choice != '5');
    
}
    
    static void option1(List<Emergency> listIn)
    {
        System.out.println("Enter address");
        String address = EasyScanner.nextString();
        System.out.println("Enter service required");
        String service = EasyScanner.nextString();
        listIn.add(new Emergency(address, service));      
    }
   
   
    static void option2(List<Emergency> listIn)
    {
            for(Emergency item: listIn)
            {
                System.out.println(item.getAddress());
                System.out.println(item.getServiceRequired());
                if(item.getCompleted())
                {
                    System.out.println("Completed");
                }
                else
                {
                    System.out.println("Not completed");
                }
                System.out.println();
            }
           
    }
   
   
    static void option3(List<Emergency> listIn)
    {
        for(Emergency item: listIn){
             System.out.println(item.getAddress());
             System.out.println(item.getServiceRequired());
             if(item.markAsCompleted()){
             System.out.println("Completed");
             
             }
             else{
             
                 System.out.println("Not Completed");
             
             
             }
        }
           
    }
   
   
    static void option4(List<Emergency> listIn)
    {
        for(Emergency item: listIn){
        System.out.println(item.getAddress());
        System.out.println(item.getServiceRequired());
        if(item != item.markAsCompleted()){
            
            System.out.println("Not Completed");
        
        }
        else{
        
            System.out.println("Completed");
        
        }
        }
        
        
        }



}
