/**
 * 
 * @author Daniel Agbolade
 * U2031559
 * CN6008
 */

public class RobotMonitor
{  
   	public static final int MIN = 1;
        public static final int MAX = 6;
	
        
        private int row, col;
        public Move reqMove;
        
        
        
        public boolean inv() 
   	{
            return(inRange(row) && inRange(col) && 
                    (reqMove == Move.RIGHT || reqMove == Move.LEFT ||reqMove == Move.DOWN|| reqMove == null));            
   	}
   	
   	// initialisation
   	public RobotMonitor()
   	{
           row = 1;
           col = 1;
           reqMove = null;
           
           if(!inv()){
           
               throw new VDMException("Broken Invariant");
           
           }
   	}
        
        
        public boolean inRange(int number){
        
            if(MIN <= number && number <= MAX){
            return true;
            
            
            
            
            } else
            {
            
                return false;
            
            }
        
        
        }
   
   	//operations
   	public int GetCol()
	{
            return col;
	}
	
	public int GetRow()
	{
            return row;
	}
        
        public Move GetMove()
        {
            
            return reqMove;
        }
	
   	public void MoveRight() 
   	{
            if((col >= MIN && col < MAX)&& (row >= MIN && row <= MAX)&&(reqMove != Move.LEFT))
            {
            
            col = col + 1;
            reqMove = Move.RIGHT;
            
            }
            else
            {
                throw new VDMException("Broken Preconditon");
            
            
            }
            
            if(!inv())
            {
                throw new VDMException("Broken Invariant");
            
            
            }
	}
	
	
	public void MoveLeft() 
   	{
            if((col >= MIN && col < MAX)&& (row >= MIN && row <= MAX)&&(reqMove != Move.RIGHT))
            {
            
            col = col - 1;
            reqMove = Move.LEFT;
            
            } 
            
            else
            {
                throw new VDMException("Broken Preconditon");
            
            
            }
            
            if(!inv())
            {
                throw new VDMException("Broken Invariant");
            
            
            }
	}
	
	public void MoveDown() 
   	{
            if((col >= MIN && col <= MAX)&& (row >= MIN && row < MAX)&&(reqMove != Move.UP))
            {
            
            row = row + 1;
            reqMove = Move.DOWN;           
	}
             else
            {
                throw new VDMException("Broken Preconditon");
            
            
            }
            
            if(!inv())
            {
                throw new VDMException("Broken Invariant");
            
            
            }
        }
            
	
	public void MoveUp() 
   	{
             if((col > MIN && col <= MAX)&& (row > MIN && row < MAX)&&(reqMove != Move.DOWN))
            {
            
            row = row - 1;
            reqMove = Move.UP;           
	}  
             else
            {
                throw new VDMException("Broken Preconditon");
            
            
            }
            
            if(!inv())
            {
                throw new VDMException("Broken Invariant");
            
            
            }
             
	}
	
	public void Exit()
   	{
            if(row == 6 && col == 6)
            {
                System.out.println("GAME OVER!!!!");
                row = 1;
                col = 1;
      
            
            }
   	}
        
        // toString method added
        //public String toString()
        //{
            // modify if you are using the text based tester
            //return " ";
        //}
}